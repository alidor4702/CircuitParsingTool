package Phase1_2_3;

public class XNORGate extends Gate {

    public XNORGate(Wire input1, Wire input2, Wire output) {
        super(input1, input2, output);
    }

    @Override
    public void computeOutput() {
        // XNOR gate logic: output is true if inputs are the same
        boolean result = !(getInput1().getValue() ^ getInput2().getValue());
        getOutput().setValue(result);
    }

    @Override
    public GateType getGateType() {
        return GateType.XNOR_GATE;
    }
}