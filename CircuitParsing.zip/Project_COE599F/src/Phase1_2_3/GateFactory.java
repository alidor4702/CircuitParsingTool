package Phase1_2_3;

public class GateFactory {

}
