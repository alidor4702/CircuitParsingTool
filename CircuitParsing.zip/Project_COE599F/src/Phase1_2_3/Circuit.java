package Phase1_2_3;

import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Collectors;

public class Circuit {
    private String name;
    private Map<Integer, Wire> wireMap;
    private List<Gate> listOfGates;
    private Map<Integer, List<Wire>> fanoutWireMap; // Map to keep track of fanout wires

    public Circuit(String definition) {
        wireMap = new HashMap<>();

        listOfGates = new ArrayList<>();
 
        fanoutWireMap = new HashMap<>();
        parseDefinition(definition);
    }

    private void parseDefinition(String definition) {
        Scanner scanner = new Scanner(definition);

        name = scanner.nextLine().substring(2).trim();
        for (int i = 0; i < 4; i++) {
            scanner.nextLine();
        }

        Pattern inputOutputPattern = Pattern.compile("(INPUT|OUTPUT)\\((\\d+)\\)");
        Pattern gatePattern = Pattern.compile("(\\d+) = (AND|NAND|OR|NOR|XOR|XNOR|NOT)\\(([^)]+)\\)");
        Map<Integer, Integer> fanoutCounts = new HashMap<>(); // Tracks the count of fanouts for each wire

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            Matcher ioMatcher = inputOutputPattern.matcher(line);
            Matcher gateMatcher = gatePattern.matcher(line);
            
            if (ioMatcher.find()) {
                int wireNumber = Integer.parseInt(ioMatcher.group(2));
                Wire wire = new Wire(wireNumber, ioMatcher.group(1).equals("OUTPUT") ? WireType.OUTPUT_WIRE : WireType.INPUT_WIRE);
                wireMap.put(wireNumber, wire);
            } else if (gateMatcher.find()) {
                int outputWireNumber = Integer.parseInt(gateMatcher.group(1));
                String gateType = gateMatcher.group(2);
                String[] inputNumbers = gateMatcher.group(3).split(", ");
                List<Wire> inputWires = new ArrayList<>();

                for (String inputNumber : inputNumbers) {
                    int inputWireNumber = Integer.parseInt(inputNumber);
                    // Increment the fanout count for this wire number
                    int count = fanoutCounts.getOrDefault(inputWireNumber, 0) + 1;
                    fanoutCounts.put(inputWireNumber, count);

                    // Create a fanout wire if this wire is used more than once
                    Wire wire = wireMap.computeIfAbsent(inputWireNumber, num -> new Wire(num, WireType.INTERNAL_WIRE));
                    if (count > 1) {
                        // If it's the first fanout, create a fanout for the original wire as well
                        if (count == 2) {
                        	// If it's the first fanout, create a fanout for the original wire as well
                        	Wire originalFanoutWire = new Wire(
                        	    inputWireNumber * 100 + 1, // Unique identifier for the fanout wire
                        	    wire.getValue(),           // Initial value
                        	    WireType.FANOUT_WIRE,      // Wire type set to FANOUT_WIRE
                        	    false,                     // faultCheck is false by default
                        	    false                      // faultValue is false by default (stuck at 0)
                        	);
                        	wireMap.put(originalFanoutWire.getName(), originalFanoutWire);
                            // Replace the original wire in previous gates with this fanout wire
                            replaceWireInGates(wire, originalFanoutWire);
                            // Add the original fanout wire to the fanout map
                            fanoutWireMap.computeIfAbsent(inputWireNumber, k -> new ArrayList<>()).add(originalFanoutWire);
                        }
                        // Create the new fanout wire
                        Wire fanoutWire = new Wire(
                        	    inputWireNumber * 100 + count, // Unique identifier for the fanout wire
                        	    wire.getValue(),               // Initial value
                        	    WireType.FANOUT_WIRE,          // Wire type set to FANOUT_WIRE
                        	    false,                         // faultCheck is false by default
                        	    false                          // faultValue is false by default (stuck at 0)
                        	);
                        wireMap.put(fanoutWire.getName(), fanoutWire);
                        inputWires.add(fanoutWire);
                        // Add the new fanout wire to the fanout map
                        fanoutWireMap.get(inputWireNumber).add(fanoutWire);
                    } else {
                        inputWires.add(wire);
                        // Initialize the list for the fanout map
                        fanoutWireMap.computeIfAbsent(inputWireNumber, k -> new ArrayList<>()).add(wire);
                    }
                }

                Wire outputWire = wireMap.computeIfAbsent(outputWireNumber, num -> new Wire(num, WireType.INTERNAL_WIRE));
                Gate gate = createGate(gateType, inputWires, outputWire);
                listOfGates.add(gate);
            }
        }
        scanner.close();
    }
    
    private void replaceWireInGates(Wire originalWire, Wire fanoutWire) {
        for (Gate gate : listOfGates) {
            if (gate.getInput1() == originalWire) {
                gate.setInput1(fanoutWire);
            }
            if (gate.getInput2() == originalWire) {
                gate.setInput2(fanoutWire);
            }
            // Update the gate's output if needed
            gate.computeOutput();
        }
    }

    // Getters and setters omitted for brevity
    // Prints all input wires and their values
    public void printInputWires() {
        System.out.println("Input Wires:");
        wireMap.values().stream()
                .filter(wire -> wire.getType() == WireType.INPUT_WIRE)
                .forEach(wire -> System.out.println("Wire " + wire.getName() + ": " + (wire.getValue() ? "1" : "0")));
    }

    // Prints all output wires and their values
    public void printOutputWires() {
        System.out.println("Output Wires:");
        wireMap.values().stream()
                .filter(wire -> wire.getType() == WireType.OUTPUT_WIRE)
                .forEach(wire -> System.out.println("Wire " + wire.getName() + ": " + (wire.getValue() ? "1" : "0")));
    }

    // Prints all internal wires and their values
    public void printInternalWires() {
        System.out.println("Internal Wires:");
        wireMap.values().stream()
                .filter(wire -> wire.getType() == WireType.INTERNAL_WIRE)
                .forEach(wire -> System.out.println("Wire " + wire.getName() + ": " + (wire.getValue() ? "1" : "0")));
    }

    public void printAllWires() {
        System.out.println("All Wires:");
        wireMap.values().forEach(wire -> System.out.println(wire.toString()));
    }


    public void printAllGates() {
        System.out.println("Gates:");
        listOfGates.forEach(gate -> System.out.println(gate.toString()));
    }
    
    public String Fanout() {
        StringBuilder builder = new StringBuilder();
        builder.append("Circuit Name: ").append(name).append("\n");
        builder.append("Fanout Wires Map:\n");

        for (Map.Entry<Integer, List<Wire>> entry : fanoutWireMap.entrySet()) {
            // Original wire number
            builder.append("Wire ").append(entry.getKey()).append(": ");
            
            // List of fanout wires
            List<String> fanoutNames = entry.getValue().stream()
                                            .map(wire -> "Wire " + wire.getName() + " (Fault: " + wire.isFaultCheck() + ", Fault Value: " + wire.getFaultValue() + ")")
                                            .collect(Collectors.toList());
            
            builder.append(String.join(", ", fanoutNames)).append("\n");
        }

        return builder.toString();
    }


    public void setInputValues(String binaryString) {
        // Get a sorted list of input wires to ensure we assign the values in the correct order
    	 List<Wire> inputWires = wireMap.values().stream()
                 .filter(wire -> wire.getType() == WireType.INPUT_WIRE)
                 .sorted(Comparator.comparingInt(Wire::getName))
                 .collect(Collectors.toList());

         if (binaryString.length() != inputWires.size()) {
             throw new IllegalArgumentException("The input string length must match the number of input wires.");
         }

         for (int i = 0; i < binaryString.length(); i++) {
             char binChar = binaryString.charAt(i);
             boolean value = binChar == '1';
             Wire inputWire = inputWires.get(i);
             inputWire.setValue(value);
             propagateValueToFanouts(inputWire);
         }

         // After updating the input values, propagate the changes through the gates
         updateGateOutputs();
     }

    private void propagateValueToFanouts(Wire wire) {
        List<Wire> fanouts = fanoutWireMap.get(wire.getName());
        if (fanouts != null) {
            for (Wire fanoutWire : fanouts) {
                fanoutWire.setValue(wire.getValue());
            }
        }
    }

    public void updateGateOutputs() {
        for (Gate gate : listOfGates) {
            gate.computeOutput();
            propagateValueToFanouts(gate.getOutput());
        }
    }

    
 // Helper method to create a gate based on the type
 private Gate createGate(String gateType, List<Wire> inputWires, Wire outputWire) {
     switch (gateType) {
         case "AND":
             return new ANDGate(inputWires.get(0), inputWires.get(1), outputWire);
         case "OR":
             return new ORGate(inputWires.get(0), inputWires.get(1), outputWire);
         case "NAND":
             return new NANDGate(inputWires.get(0), inputWires.get(1), outputWire);
         case "NOR":
             return new NORGate(inputWires.get(0), inputWires.get(1), outputWire);
         case "XOR":
             return new XORGate(inputWires.get(0), inputWires.get(1), outputWire);
         case "XNOR":
             return new XNORGate(inputWires.get(0), inputWires.get(1), outputWire);
         case "NOT":
             return new NOTGate(inputWires.get(0), outputWire);
         default:
             throw new IllegalArgumentException("Unknown gate type: " + gateType);
     }
 }
    
 
 public void generateImageFromDot(String dotFilename, String imageFilename) {
	    String dotPath = "C:\\Program Files\\Graphviz\\bin\\dot.exe"; // Replace with the actual path to dot executable
	    ProcessBuilder processBuilder = new ProcessBuilder(dotPath, "-Tpng", dotFilename, "-o", imageFilename);
	    try {
	        Process process = processBuilder.start();
	        process.waitFor();
	    } catch (IOException | InterruptedException e) {
	        e.printStackTrace();
	    }
	}


 
 public void saveDotToFile(String dotDescription, String filename) {
	    try (PrintWriter out = new PrintWriter(filename)) {
	        out.println(dotDescription);
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    }
	}
 
 public String generateDot() {
	    StringBuilder dotBuilder = new StringBuilder();
	    dotBuilder.append("digraph circuit {\n");
	    dotBuilder.append("    rankdir=LR;\n\n");
	    
	    // Define nodes for wires
	    for (Wire wire : wireMap.values()) {
	        String wireLabel = "Wire " + wire.getName();
	        String wireShape = "ellipse";
	        dotBuilder.append("    \"" + wire.getName() + "\" [label=\"" + wireLabel + "\", shape=" + wireShape + "];\n");
	    }
	    
	    // Define nodes and edges for gates with specific shapes
	    for (Gate gate : listOfGates) {
	        String gateLabel = gate.getClass().getSimpleName() + gate.getOutput().getName();
	        String gateShape = getGateShape(gate);
	        dotBuilder.append("    \"" + gateLabel + "\" [label=\"" + gateLabel + "\", shape=" + gateShape + "];\n");
	        
	        // Connect input wires to gate
	        Wire input1 = gate.getInput1();
	        if (input1 != null) {
	            dotBuilder.append("    \"" + input1.getName() + "\" -> \"" + gateLabel + "\";\n");
	        }
	        Wire input2 = gate.getInput2();
	        if (input2 != null) { // For gates with two inputs
	            dotBuilder.append("    \"" + input2.getName() + "\" -> \"" + gateLabel + "\";\n");
	        }
	        
	        // Connect gate to output wire
	        Wire output = gate.getOutput();
	        dotBuilder.append("    \"" + gateLabel + "\" -> \"" + output.getName() + "\";\n");
	    }
	    
	    // Connect fanout wires to their sources with dotted lines
	    for (Map.Entry<Integer, List<Wire>> entry : fanoutWireMap.entrySet()) {
	        for (Wire fanout : entry.getValue()) {
	            dotBuilder.append("    \"" + entry.getKey() + "\" -> \"" + fanout.getName() + "\" [style=dashed];\n");
	        }
	    }
	    
	    dotBuilder.append("}\n");
	    return dotBuilder.toString();
	}

	private String getGateShape(Gate gate) {
	    if (gate instanceof ANDGate) {
	        return "invhouse"; // inverted house shape can approximate an AND gate
	    } else if (gate instanceof ORGate) {
	        return "ellipse"; // OR gates can be represented by an ellipse/circle
	    } else if (gate instanceof NOTGate) {
	        return "triangle"; // Triangle shape for NOT gate
	    } else if (gate instanceof NANDGate) {
	        return "invhouse"; // Similar to AND but you would need to add a small circle manually
	    } else if (gate instanceof NORGate) {
	        return "ellipse"; // Similar to OR but you would need to add a small circle manually
	    } else if (gate instanceof XORGate) {
	        return "diamond"; // XOR can be represented by a diamond
	    } else if (gate instanceof XNORGate) {
	        return "diamond"; // Similar to XOR but you would need to add a small circle manually
	    } else {
	        return "box";
	    }
	}



 // Method to run the interactive session
 public void runInteractiveSession() {
     Scanner scanner = new Scanner(System.in);
     String inputVector;
     boolean continueSession = true;

     while (continueSession) {
         // Ask for the input vector
         System.out.println("Enter the input vector (e.g., 0101):");
         inputVector = scanner.nextLine();
         setInputValues(inputVector);
         updateGateOutputs();
         printAllGates();
         printAllWires();

         // Ask if the user wants to implement a fault
         System.out.println("Do you want to implement a fault? (yes/no):");
         String faultDecision = scanner.nextLine();

         if ("yes".equalsIgnoreCase(faultDecision)) {
             // Ask which wire to fault and the fault value
             System.out.println("Enter the wire number to apply the fault:");
             int wireNumber = scanner.nextInt(); // Assumes wire number is an integer
             System.out.println("Enter the fault value (0 or 1):");
             boolean faultValue = scanner.nextInt() != 0;

             // Apply the fault
             Wire faultyWire = wireMap.get(wireNumber);
             if (faultyWire != null) {
                 faultyWire.setFaultCheck(true);
                 faultyWire.setFaultValue(faultValue);
             }

             // Recompute outputs after fault
             propagateValueToFanouts(faultyWire);
             updateGateOutputs();
             printAllGates();
             printAllWires();

             // Reset the fault for the next run
             faultyWire.setFaultCheck(false);
         }

         // Ask if the user wants to run another test or fault
         System.out.println("Do you want to run another fault or a different test vector? (fault/test/quit):");
         String nextAction = scanner.next();

         // Reset the circuit if needed
         if ("test".equalsIgnoreCase(nextAction)) {
             resetCircuit(); // This method needs to be implemented to reset the circuit
         } else if ("quit".equalsIgnoreCase(nextAction)) {
             continueSession = false; // Exit the loop
         }

         scanner.nextLine(); // Consume the rest of the line
     }

     scanner.close();
 }

 // Implement the resetCircuit method if it doesn't exist
 private void resetCircuit() {
     // Reset all wires to default values
     for (Wire wire : wireMap.values()) {
         wire.setValue(false);
         wire.setFaultCheck(false);
     }
     // Reset the outputs of all gates
     updateGateOutputs();
 }
 
 public void runFaultAnalysis(String inputVector) {
	    // Step 1: Run the circuit without faults and save outputs
	    setInputValues(inputVector);
	    updateGateOutputs();
	    Map<Integer, Boolean> originalOutputs = saveOutputValues();

	    // Step 2: Run the circuit with each fault
	    for (Wire wire : wireMap.values()) {
	        for (boolean faultValue : new boolean[]{false, true}) { // Stuck-at-0 and Stuck-at-1
	            // Apply fault to wire
	            wire.setFaultCheck(true);
	            wire.setFaultValue(faultValue);

	            // Run the circuit with the fault
	            setInputValues(inputVector);
	            updateGateOutputs();
	            Map<Integer, Boolean> faultyOutputs = saveOutputValues();

	            // Compare outputs and report
	            reportFault(wire.getName(), faultValue, originalOutputs, faultyOutputs);

	            // Reset the fault for the next iteration
	            wire.setFaultCheck(false);
	        }
	    }
	}

	private Map<Integer, Boolean> saveOutputValues() {
	    return wireMap.values().stream()
	        .filter(wire -> wire.getType() == WireType.OUTPUT_WIRE)
	        .collect(Collectors.toMap(Wire::getName, Wire::getValue));
	}

	private void reportFault(int wireNumber, boolean faultValue, Map<Integer, Boolean> originalOutputs, Map<Integer, Boolean> faultyOutputs) {
	    System.out.println("Fault Simulation for wire " + wireNumber + " stuck-at-" + (faultValue ? "1" : "0") + ":");
	    boolean discrepancyFound = false;
	    for (Integer outputWireNumber : originalOutputs.keySet()) {
	        if (!Objects.equals(originalOutputs.get(outputWireNumber), faultyOutputs.get(outputWireNumber))) {
	            System.out.println("Output wire " + outputWireNumber + " differs from expected. Faulty value: " +
	                    faultyOutputs.get(outputWireNumber) + ", Expected value: " + originalOutputs.get(outputWireNumber));
	            discrepancyFound = true;
	        }
	    }
	    if (!discrepancyFound) {
	        System.out.println("No discrepancy found for this fault.");
	    }
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void runBatchFaultAnalysis() {
	    Scanner scanner = new Scanner(System.in);
	    boolean continueSession = true;

	    System.out.println("Choose the mode of operation:");
	    System.out.println("(1) Specific Input Vector Fault Analysis");
	    System.out.println("(2) All Input Vectors Fault Analysis");
	    int mode = scanner.nextInt();
	    scanner.nextLine(); // Consume newline

	    long totalStartTime = System.currentTimeMillis(); // Start measuring total time
	    double totalFaultCoverage = 0;
	    double totalFaultEfficiency = 0;
	    int totalInputVectors = 0;

	    if (mode == 1) {


	        // Specific Input Vector Fault Analysis
	        System.out.println("Enter the input vector (e.g., 0101):");
	        String inputVector = scanner.nextLine();
	        setInputValues(inputVector);
	        updateGateOutputs();

	        System.out.println("Do you want to run (1) Batch Fault Analysis or (2) All Faults Analysis? Enter 1 or 2:");
	        int analysisChoice = scanner.nextInt();
	        scanner.nextLine();  // Consume the rest of the line

	        List<FaultResult> faultResults = new ArrayList<>();
	        int totalFaults = 0;
	        int undetectableFaults = 0; 

	        long startTime = System.currentTimeMillis(); // Start measuring time

	        if (analysisChoice == 1) {
	            // Run Batch Fault Analysis
	            System.out.println("Enter the list of faults in the format wireNumber,faultValue (e.g., 2,1; 3,0); enter 'done' when finished:");
	            while (true) {
	                String faultInput = scanner.nextLine();
	                if ("done".equalsIgnoreCase(faultInput)) {
	                    break;
	                }
	                String[] parts = faultInput.split(",");
	                if (parts.length != 2) {
	                    System.out.println("Invalid format. Please re-enter the fault.");
	                    continue;
	                }
	                int wireNumber = Integer.parseInt(parts[0].trim());
	                boolean faultValue = Integer.parseInt(parts[1].trim()) != 0;
	                FaultResult faultResult = processFault(wireNumber, faultValue, inputVector);
	                faultResults.add(faultResult);
	            }
	        } else if (analysisChoice == 2) {
	            // Run All Faults Analysis
	            faultResults = runAllFaultsAnalysis(inputVector);
	            totalFaults = wireMap.size() * 2;
	        } else {
	            System.out.println("Invalid choice. Please enter 1 or 2.");
	            continueSession = false;
	        }

	        // Report all faults
	        for (FaultResult faultResult : faultResults) {
	            faultResult.report();
	        }

	        // Stop measuring time and calculate the processing time
	        long endTime = System.currentTimeMillis();
	        long processingTime = endTime - startTime;
	        System.out.println("Processing Time: " + processingTime + " milliseconds");
	    
	    	
	    	
	    } else if (mode == 2 && continueSession) {
	        // All Input Vectors Fault Analysis
	        int inputWiresCount = getInputWiresCount();
	        int totalCombinations = (int) Math.pow(2, inputWiresCount);
	        for (int i = 0; i < totalCombinations; i++) {
	            String inputVector = Integer.toBinaryString(i);
	            inputVector = String.format("%" + inputWiresCount + "s", inputVector).replace(' ', '0');

	            System.out.println("///////// Input Vector: " + inputVector + " //////////");
	            setInputValues(inputVector);
	            updateGateOutputs();

	            List<FaultResult> faultResults = runAllFaultsAnalysis(inputVector);
	            reportAllFaults(faultResults);

	            double faultCoverage = calculateFaultCoverage(faultResults);
	            double faultEfficiency = calculateFaultEfficiency(faultResults);
	            System.out.println("Fault Coverage: " + faultCoverage * 100 + "%");
	            System.out.println("Fault Efficiency: " + faultEfficiency * 100 + "%");

	            totalFaultCoverage += faultCoverage;
	            totalFaultEfficiency += faultEfficiency;
	            totalInputVectors++;
	        }
	    } else {
	        System.out.println("Invalid choice. Please enter 1 or 2.");
	        continueSession = false;
	    }

	    if (continueSession && mode == 2) {
	        long totalEndTime = System.currentTimeMillis();
	        long totalProcessingTime = totalEndTime - totalStartTime;
	        System.out.println("Total Testing Time: " + totalProcessingTime + " milliseconds");

	        // Calculate and display final averages for Fault Coverage and Fault Efficiency
	        double finalFaultCoverage = totalFaultCoverage / totalInputVectors;
	        double finalFaultEfficiency = totalFaultEfficiency / totalInputVectors;
	        System.out.println("Final Fault Coverage: " + finalFaultCoverage * 100 + "%");
	        System.out.println("Final Fault Efficiency: " + finalFaultEfficiency * 100 + "%");
	    }

	    scanner.close();
	}

	private List<FaultResult> runAllFaultsAnalysis(String inputVector) {
	    List<FaultResult> faultResults = new ArrayList<>();
	    for (Wire wire : wireMap.values()) {
	        for (boolean faultValue : new boolean[]{false, true}) {
	            FaultResult faultResult = processFault(wire.getName(), faultValue, inputVector);
	            faultResults.add(faultResult);
	        }
	    }
	    return faultResults;
	}

	private double calculateFaultCoverage(List<FaultResult> faultResults) {
	    int detectedFaults = 0;
	    for (FaultResult result : faultResults) {
	        if (result.hasDiscrepancy()) {
	            detectedFaults++;
	        }
	    }
	    return (double) detectedFaults / (2 * wireMap.size());
	}

	private double calculateFaultEfficiency(List<FaultResult> faultResults) {
	    int detectedFaults = 0;
	    int undetectableFaults = 0; // Logic to determine undetectable faults goes here
	    for (FaultResult result : faultResults) {
	        if (result.hasDiscrepancy()) {
	            detectedFaults++;
	        }
	    }
	    int totalFaults = 2 * wireMap.size();
	    return totalFaults == undetectableFaults ? 0 : (double) detectedFaults / (totalFaults - undetectableFaults);
	}

	private int getInputWiresCount() {
	    // Logic to count the number of input wires in your circuit goes here
	    // You can count the input wires from wireMap or another data structure that you have
	    return (int) wireMap.values().stream().filter(wire -> wire.getType() == WireType.INPUT_WIRE).count();
	}

	// Other necessary methods (like processFault, reportAllFaults, etc.) should be implemented as per your existing code.



	private FaultResult processFault(int wireNumber, boolean faultValue, String inputVector) {
	    Wire faultyWire = wireMap.get(wireNumber);
	    Map<Integer, Boolean> originalOutputs = saveOutputValues();

	    faultyWire.setFaultCheck(true);
	    faultyWire.setFaultValue(faultValue);
	    setInputValues(inputVector);
	    updateGateOutputs();
	    Map<Integer, Boolean> faultyOutputs = saveOutputValues();

	    faultyWire.setFaultCheck(false);

	    return new FaultResult(wireNumber, faultValue, compareOutputs(originalOutputs, faultyOutputs));
	}

	private void reportAllFaults(List<FaultResult> faultResults) {
	    for (FaultResult result : faultResults) {
	        result.report();
	    }
	}

	private Map<Integer, Boolean[]> compareOutputs(Map<Integer, Boolean> originalOutputs, Map<Integer, Boolean> faultyOutputs) {
	    Map<Integer, Boolean[]> discrepancies = new HashMap<>();

	    for (Map.Entry<Integer, Boolean> entry : originalOutputs.entrySet()) {
	        Integer wireNumber = entry.getKey();
	        Boolean originalValue = entry.getValue();
	        Boolean faultyValue = faultyOutputs.get(wireNumber);

	        if (!Objects.equals(originalValue, faultyValue)) {
	            discrepancies.put(wireNumber, new Boolean[] {originalValue, faultyValue});
	        }
	    }

	    return discrepancies;
	}

	
	public void runComprehensiveFaultAnalysis() {
	    int inputWiresCount = getInputWiresCount();
	    int totalCombinations = (int) Math.pow(2, inputWiresCount);

	    Map<String, List<String>> faultDetectionMap = new HashMap<>();
	    Set<String> allPossibleFaults = new HashSet<>();
	    int totalFaults = wireMap.size() * 2; // Each wire can have 2 faults (stuck-at-0 and stuck-at-1)

	    for (Wire wire : wireMap.values()) {
	        for (boolean faultValue : new boolean[]{false, true}) {
	            String faultKey = "Wire " + wire.getName() + " stuck-at-" + (faultValue ? "1" : "0");
	            allPossibleFaults.add(faultKey);
	            boolean faultDetected = false;

	            for (int i = 0; i < totalCombinations && !faultDetected; i++) {
	                String inputVector = Integer.toBinaryString(i);
	                inputVector = String.format("%" + inputWiresCount + "s", inputVector).replace(' ', '0');

	                setInputValues(inputVector);
	                updateGateOutputs();
	                Map<Integer, Boolean> originalOutputs = saveOutputValues();

	                wire.setFaultCheck(true);
	                wire.setFaultValue(faultValue);
	                setInputValues(inputVector);
	                updateGateOutputs();
	                Map<Integer, Boolean> faultyOutputs = saveOutputValues();

	                wire.setFaultCheck(false);

	                if (!faultyOutputs.equals(originalOutputs)) {
	                    faultDetectionMap.computeIfAbsent(faultKey, k -> new ArrayList<>()).add(inputVector);
	                    faultDetected = true;
	                }
	            }
	        }
	    }

	    // Calculate Fault Coverage and Efficiency
	    int detectedFaults = faultDetectionMap.size();
	    double faultCoverage = (double) detectedFaults / totalFaults;
	    double faultEfficiency = (double) detectedFaults / totalFaults; // Assuming all faults are detectable

	    // Reporting detected and undetected faults
	    System.out.println("Fault Analysis Report:");
	    for (String fault : allPossibleFaults) {
	        System.out.print("Fault: " + fault);
	        if (faultDetectionMap.containsKey(fault)) {
	            System.out.println(" - Detected by input vector(s): " + String.join(", ", faultDetectionMap.get(fault)));
	        } else {
	            System.out.println(" - Not detected by any input vector.");
	        }
	    }

	    // Report Fault Coverage and Efficiency
	    System.out.println("Fault Coverage: " + (faultCoverage * 100) + "%");
	    System.out.println("Fault Efficiency: " + (faultEfficiency * 100) + "%");
	}

	

 
}
