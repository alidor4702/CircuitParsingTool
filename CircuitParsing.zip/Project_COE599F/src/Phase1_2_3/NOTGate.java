package Phase1_2_3;

public class NOTGate extends Gate {

    // Since NOT gates only have one input, we can use a constructor that only requires one input wire.
    // We can pass the same wire as both input1 and input2 to the superclass constructor.
    public NOTGate(Wire input, Wire output) {
        super(input, input, output); // Pass 'input' as both input1 and input2
    }

    @Override
    public void computeOutput() {
        // NOT gate inverts its single input to produce its output
        boolean result = !getInput1().getValue();
        getOutput().setValue(result);
    }

    @Override
    public GateType getGateType() {
        return GateType.NOT_GATE;
    }
}