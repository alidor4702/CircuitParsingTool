package Phase1_2_3;

public class Wire {

    private int name;        // Unique identifier for the wire
    private boolean value;   // Logical value (true for high/1, false for low/0)
    private WireType type;   // Type of wire (INPUT, OUTPUT, INTERNAL, FANOUT)
    private boolean faultCheck;  // Flag to check if the wire has a fault
    private boolean faultValue;  // Fault value to use if faultCheck is true

    // Constructor with all properties
    public Wire(int name, boolean value, WireType type, boolean faultCheck, boolean faultValue) {
        this.name = name;
        this.value = value;
        this.type = type;
        this.faultCheck = faultCheck;
        this.faultValue = faultValue;
    }

    // Overloaded constructor for no fault
    public Wire(int name, WireType type) {
        this(name, false, type, false, false); // Default value set to false, no fault
    }

    // Getter and setter for name
    public int getName() {
        return name;
    }

    public void setName(int name) {
        this.name = name;
    }

    // Getter and setter for value
    public boolean getValue() {
        // If there's a fault, return the fault value instead of the actual value
        return faultCheck ? faultValue : value;
    }

    public void setValue(boolean value) {
        // If there's a fault, the wire's value should be the fault value instead of the actual value
        if (!faultCheck) {
            this.value = value;
        }
    }

    // Getter and setter for type
    public WireType getType() {
        return type;
    }

    public void setType(WireType type) {
        this.type = type;
    }

    // Getter and setter for faultCheck
    public boolean isFaultCheck() {
        return faultCheck;
    }

    public void setFaultCheck(boolean faultCheck) {
        this.faultCheck = faultCheck;
    }

    // Getter and setter for faultValue
    public boolean getFaultValue() {
        return faultValue;
    }

    public void setFaultValue(boolean faultValue) {
        this.faultValue = faultValue;
    }

    // toString method to display wire information, including fault status
    @Override
    public String toString() {
        String faultStatus = faultCheck ? "Faulty (stuck at " + (faultValue ? "1" : "0") + ")" : "No fault";
        return "Wire{" +
                "name=" + name +
                ", value=" + (getValue() ? '1' : '0') + // Use getValue to account for faults
                ", type=" + type +
                ", status=" + faultStatus +
                '}';
    }
}
