package Phase1_2_3;

public enum WireType {
    INPUT_WIRE,
    OUTPUT_WIRE,
    INTERNAL_WIRE,
    FANOUT_WIRE;
}
