package Phase1_2_3;

public class XORGate extends Gate {

    public XORGate(Wire input1, Wire input2, Wire output) {
        super(input1, input2, output);
    }

    @Override
    public void computeOutput() {
        // XOR gate logic: output is true if inputs are different
        boolean result = getInput1().getValue() ^ getInput2().getValue();
        getOutput().setValue(result);
    }

    @Override
    public GateType getGateType() {
        return GateType.XOR_GATE;
    }
}