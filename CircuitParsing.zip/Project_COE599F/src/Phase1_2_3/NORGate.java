package Phase1_2_3;

public class NORGate extends Gate {

    public NORGate(Wire input1, Wire input2, Wire output) {
        super(input1, input2, output);
    }

    @Override
    public void computeOutput() {
        // NOR gate logic: output is true if both inputs are false
        boolean result = !(getInput1().getValue() || getInput2().getValue());
        getOutput().setValue(result);
    }

    @Override
    public GateType getGateType() {
        return GateType.NOR_GATE;
    }
}