package Phase1_2_3;

import java.util.*;

public class FaultResult {
    private final int wireNumber;
    private final boolean faultValue;
    private final Map<Integer, Boolean[]> discrepancies;

    public FaultResult(int wireNumber, boolean faultValue, Map<Integer, Boolean[]> discrepancies) {
        this.wireNumber = wireNumber;
        this.faultValue = faultValue;
        this.discrepancies = discrepancies;
    }

    public void report() {
        System.out.println("Fault Simulation for wire " + wireNumber + " stuck-at-" + (faultValue ? "1" : "0") + ":");
        boolean discrepancyFound = false;
        for (Map.Entry<Integer, Boolean[]> entry : discrepancies.entrySet()) {
            if (!Objects.equals(entry.getValue()[0], entry.getValue()[1])) {
                System.out.println("Output wire " + entry.getKey() + " differs from expected. Faulty value: " +
                        entry.getValue()[1] + ", Expected value: " + entry.getValue()[0]);
                discrepancyFound = true;
            }
        }
        if (!discrepancyFound) {
            System.out.println("No discrepancy found for this fault.");
        }
    }
    public boolean hasDiscrepancy() {
        for (Boolean[] values : discrepancies.values()) {
            if (!Objects.equals(values[0], values[1])) {
                return true; // Discrepancy found
            }
        }
        return false; // No discrepancies
    }
}
