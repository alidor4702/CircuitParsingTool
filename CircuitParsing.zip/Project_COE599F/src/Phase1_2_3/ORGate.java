package Phase1_2_3;

public class ORGate extends Gate {

    public ORGate(Wire input1, Wire input2, Wire output) {
        super(input1, input2, output);
    }

    @Override
    public void computeOutput() {
        boolean result = getInput1().getValue() || getInput2().getValue();
        getOutput().setValue(result);
    }

    @Override
    public GateType getGateType() {
        return GateType.OR_GATE;
    }
}