package Phase1_2_3;

public class Main {

	public static void main(String[] args) {
		Circuit c17 = new Circuit("# c17\r\n"
				+ "# 5 inputs\r\n"
				+ "# 2 outputs\r\n"
				+ "# 1 inverter\r\n"
				+ "# 6 gates ( 6 ORs )\r\n"
				+ "\r\n"
				+ "INPUT(1)\r\n"
				+ "INPUT(2)\r\n"
				+ "INPUT(3)\r\n"
				+ "INPUT(6)\r\n"
				+ "INPUT(7)\r\n"
				+ "\r\n"
				+ "OUTPUT(22)\r\n"
				+ "OUTPUT(23)\r\n"
				+ "\r\n"
				+ "10 = OR(1, 3)\r\n"
				+ "11 = NOT(10)\r\n"
				+ "12 = OR(3, 6)\r\n"
				+ "16 = OR(2, 12)\r\n"
				+ "19 = OR(12, 7)\r\n"
				+ "22 = OR(11, 16)\r\n"
				+ "23 = OR(16, 19)");
		
		
				//c17.setInputValues("00100");
				//c17.printAllGates();
				//c17.printAllWires();
				//c17.runInteractiveSession();
				//c17.printInputWires();
				//System.out.println(c17.Fanout());
				//c17.runFaultAnalysis("00000");
				c17.runComprehensiveFaultAnalysis();
				c17.runBatchFaultAnalysis();
		
//		Circuit c1 = new Circuit("# c2\r\n"
//				+ "# 2 inputs\r\n"
//				+ "# 1 outputs\r\n"
//				+ "# 1 inverter\r\n"
//				+ "# 2 gates ( 1 ANDs + 1 ORs )\r\n"
//				+ "\r\n"
//				+ "INPUT(1)\r\n"
//				+ "INPUT(2)\r\n"
//				+ "\r\n"
//				+ "OUTPUT(6)\r\n"
//				+ "\r\n"
//				+ "5 = AND(1, 2)\r\n"
//				+ "6 = NOT(2)\r\n"
//				+ "7 = OR(5, 6)");		
//				
//				c1.setInputValues("11");
//				c1.printAllGates();
//				c1.printAllWires();
		
		
//				String dotDescription = c17.generateDot(); // Generate the DOT description
//				System.out.println(dotDescription);
//				String dotFilename = "circuit.dot"; // Set the DOT filename
//			    String imageFilename = "circuit.png"; // Set the image filename
//			    c17.saveDotToFile(dotDescription, dotFilename); // Save DOT to file
//			    c17.generateImageFromDot(dotFilename, imageFilename); // Generate the image
	}

}
