package Phase1_2_3;

public abstract class Gate {
    private Wire input1;
    private Wire input2;
    private Wire output;

    // Constructor
    public Gate(Wire input1, Wire input2, Wire output) {
        this.input1 = input1;
        this.input2 = input2;
        this.output = output;
        computeOutput();
    }

    // Getters and setters for input1
    public Wire getInput1() {
        return input1;
    }

    public void setInput1(Wire input1) {
        this.input1 = input1;
    }

    // Getters and setters for input2
    public Wire getInput2() {
        return input2;
    }

    public void setInput2(Wire input2) {
        this.input2 = input2;
    }

    // Getters and setters for output
    public Wire getOutput() {
        return output;
    }

    public void setOutput(Wire output) {
        this.output = output;
    }

    // Abstract method to compute output
    public abstract void computeOutput();

    // Enum for Gate types
    public enum GateType {
        AND_GATE,
        OR_GATE,
    	XOR_GATE,
        NAND_GATE,
        NOR_GATE,
        NOT_GATE,
        XNOR_GATE;
    	
    }

    // Get the type of the gate
    public abstract GateType getGateType();
 // In the Gate class or subclasses where you override toString()
    @Override
    public String toString() {
        // Get names of input wires, checking if they are fanout wires
        String input1Name = getInput1().getType() == WireType.FANOUT_WIRE ? "Fanout from " + getInput1().getName() : String.valueOf(getInput1().getName());
        String input2Name = getInput2().getType() == WireType.FANOUT_WIRE ? "Fanout from " + getInput2().getName() : String.valueOf(getInput2().getName());

        return getGateType() + " Gate - Input wires: " + input1Name + ", " + input2Name + " | Output wire: " + getOutput().getName();
    }

    
}


